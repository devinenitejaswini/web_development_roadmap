# BOOTSTRAP
<img src="/images/Bootstrap_logo.svg" width="50" height="50"> <img src="/images/Bootstrap_logo.svg" width="50" height="50"> <img src="/images/Bootstrap_logo.svg" width="50" height="50"> 

Bootstrap is a free, open source HTML, CSS, and JavaScript framework for quickly building responsive websites.

Initially, Bootstrap was called Twitter Blueprint and was developed by a team working at Twitter. It supports responsive design and features predefined design templates that you can use out of the box, or customize for your needs with your code. You don't need to worry about compatibility with other browsers either, as Bootstrap is compatible with all modern browsers and newer versions of Internet Explorer.

## COURSES AND REFERENCE
1. [W3-SCHOOLS](https://www.w3schools.com/bootstrap5/index.php)
2. [YOUTUBE](https://www.youtube.com/watch?v=-qfEOE4vtxE)
3. [UDEMY](https://www.udemy.com/course/the-complete-web-development-bootcamp/)
