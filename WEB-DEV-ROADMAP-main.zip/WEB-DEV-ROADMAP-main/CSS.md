# CSS
<img src="/images/css.svg" width="50" height="50"> <img src="/images/css.svg" width="50" height="50"> <img src="/images/css.svg" width="50" height="50">

Cascading Style Sheets (CSS) is a stylesheet language used to describe the presentation of a document written in HTML. CSS describes how elements should be rendered on screen, on paper, in speech, or on other media.

## COURSES AND REFERENCE
1. [W3-SCHOOLS](https://www.w3schools.com/css/)
2. [YOUTUBE](https://www.youtube.com/watch?v=1Rs2ND1ryYc)
3. [UDEMY](https://www.udemy.com/course/the-complete-web-development-bootcamp/)
