# HTML
<img src="images/HTML.svg" width="50" height="50"> <img src="images/HTML.svg" width="50" height="50"> <img src="images/HTML.svg" width="50" height="50">

HTML (HyperText Markup Language) is the most basic building block of the Web. It defines the meaning and structure of web content. Other technologies besides HTML are generally used to describe a web page's appearance/presentation (CSS) or functionality/behavior (JavaScript).

Basically HTML is the skeleton for a website.

## COURSES AND REFERENCE
1. [W3-Schools](https://www.w3schools.com/html/default.asp)
2. [YOUTUBE](https://www.youtube.com/watch?v=qz0aGYrrlhU)
3. [UDEMY](https://www.udemy.com/course/the-complete-web-development-bootcamp/)
