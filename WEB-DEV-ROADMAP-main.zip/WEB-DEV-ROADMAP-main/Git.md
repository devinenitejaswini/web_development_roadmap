# GIT
<img src="images/git.png" width="250" height="100">

Git is free and open source software for distributed version control: tracking changes in any set of files, usually used for coordinating work among programmers collaboratively developing source code during software development

## COURSES AND REFERENCE
1. [W3-SCHOOLS](https://www.w3schools.com/git/)
2. [YOUTUBE](https://www.youtube.com/watch?v=RGOj5yH7evk)
3. [UDEMY](https://www.udemy.com/course/git-complete/)
