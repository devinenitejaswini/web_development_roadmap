# JAVASCRIPT
<img src="images/js.svg" width="50" height="50"> <img src="images/js.svg" width="50" height="50"> <img src="images/js.svg" width="50" height="50">

JavaScript (JS) is a lightweight, interpreted, or just-in-time compiled programming language with first-class functions. While it is most well-known as the scripting language for Web pages.

Do not confuse JavaScript with the Java programming language. Both "Java" and "JavaScript" are trademarks or registered trademarks of Oracle in the U.S. and other countries. However, the two programming languages have very different syntax, semantics, and use.

## COURSES AND REFERENCE
1. [W3-SCHOOLS](https://www.w3schools.com/js/)
2. [YOUTUBE](https://www.youtube.com/watch?v=jS4aFq5-91M)
3. [UDEMY](https://www.udemy.com/course/the-complete-web-development-bootcamp/)
