# FLASK
<img src="images/flask.png" > 
Flask is a micro web framework written in Python. It is classified as a microframework because it does not require particular tools or libraries. It has no database abstraction layer, form validation, or any other components where pre-existing third-party libraries provide common functions.

## COURSES AND REFERENCE

1. [TUTORIALS-POINT](https://www.tutorialspoint.com/flask/index.htm)
2. [YOUTUBE](https://www.youtube.com/watch?v=Z1RJmh_OqeA)
3. [UDEMY](https://www.udemy.com/course/rest-api-flask-and-python/)
