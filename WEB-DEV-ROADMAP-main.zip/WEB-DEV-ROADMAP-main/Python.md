# PYTHON
<img src="images/Python-logo-notext.svg" width="50" height="50"> <img src="images/Python-logo-notext.svg" width="50" height="50"> <img src="images/Python-logo-notext.svg" width="50" height="50">

The backend of a website can be written in many different programming languages. It is becoming increasingly common for to use Python for the backend of a website.

## COURSES AND REFERENCE
1. [W3-SCHOOLS](https://www.w3schools.com/python/)
2. [YOUTUBE](https://www.youtube.com/watch?v=jBzwzrDvZ18)
3. [UDEMY](https://www.udemy.com/course/100-days-of-code/)
