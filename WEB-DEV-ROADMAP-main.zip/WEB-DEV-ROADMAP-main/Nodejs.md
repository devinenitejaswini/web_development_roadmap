# NODE.JS 
<img src="images/nodejs.png" width="200" height="150"> 

Node.js is an open-source, cross-platform, back-end JavaScript runtime environment that runs on a JavaScript Engine and executes JavaScript code outside a web browser, which was designed to build scalable network applications.

## COURSES AND REFERENCE
1. [W3-SCHOOLS](https://www.w3schools.com/nodejs/)
2. [YOUTUBE](https://www.youtube.com/watch?v=Oe421EPjeBE)
3. [UDEMY](https://www.udemy.com/course/nodejs-the-complete-guide/)
